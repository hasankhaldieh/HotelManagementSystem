﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class adminrequestpage : Form
    {
        private Button acceptButton;
        private Button rejectButton;

        private string connectionString = "Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;";
        public adminrequestpage()
        {
            InitializeComponent();
            LoadPasswordResetRequests();
        }

        private void LoadPasswordResetRequests()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT request_id as 'Request Number', client_username as 'Client Username' , request_time as 'Request Time', processed as 'Processed' FROM resetpassword";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgv.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading password reset requests: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AcceptButton_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count > 0)
            {
                int requestId = Convert.ToInt32(dgv.SelectedRows[0].Cells["Request Number"].Value);
                UpdateRequestStatus(requestId, true);
            }
            else
            {
                MessageBox.Show("Please select a password reset request to accept.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void RejectButton_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count > 0)
            {
                int requestId = Convert.ToInt32(dgv.SelectedRows[0].Cells["Request Number"].Value);
                UpdateRequestStatus(requestId, false);
            }
            else
            {
                MessageBox.Show("Please select a password reset request to reject.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void UpdateRequestStatus(int requestId, bool processed)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE resetpassword SET processed = @processed WHERE request_id = @requestId";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@processed", processed);
                    command.Parameters.AddWithValue("@requestId", requestId);

                    connection.Open();
                    command.ExecuteNonQuery();

                    MessageBox.Show("Password reset request updated successfully.");
                    LoadPasswordResetRequests();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while updating password reset request: " + ex.Message);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            admindashboard a = new admindashboard();
            a.Show();
            this.Hide();
        }

        private void close_button_Click_1(object sender, EventArgs e)
        {
            login login = new login();
            login.Show();
            this.Hide();
        }
    }
}
