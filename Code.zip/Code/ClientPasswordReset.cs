﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class ClientPasswordReset : Form
    {
        private string connectionString = "Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;";
        private string username;
        public ClientPasswordReset(string username )
        {
            InitializeComponent();
            this.username = username;
        }



        private void resetButton_Click(object sender, EventArgs e)
        {
            string newPassword = newPasswordTextBox.Text;
            string confirmPassword = confirmPasswordTextBox.Text;

            if (string.IsNullOrWhiteSpace(newPassword) || string.IsNullOrWhiteSpace(confirmPassword))
            {
                MessageBox.Show("Please enter both new password and confirm password.");
                return;
            }

            if (newPassword != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.");
                return;
            }

            string passwordPattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$";
            if (!Regex.IsMatch(newPassword, passwordPattern))
            {
                MessageBox.Show("Password must contain at least one lowercase letter, one uppercase letter, one digit, one special character, and be at least 8 characters long.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand("UPDATE client SET password = @newPassword WHERE username = @username", connection);
                    command.Parameters.AddWithValue("@newPassword", newPassword);
                    command.Parameters.AddWithValue("@username", username);
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    SqlCommand deleteCommand = new SqlCommand("DELETE FROM resetpassword WHERE client_username = @username", connection);

                    deleteCommand.Parameters.AddWithValue("@username", username);

                    int processedRowsAffected = deleteCommand.ExecuteNonQuery();


                    if (rowsAffected > 0 && processedRowsAffected > 0)
                    {
                        MessageBox.Show("Password reset successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to reset password.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            newPasswordTextBox.Clear();
            confirmPasswordTextBox.Clear();
        }


        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            login login = new login();
            login.Show();
            this.Hide();
        }

       
    }
}
