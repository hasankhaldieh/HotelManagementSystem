﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class staffmessages : Form
    {
        private int staffId;

        public staffmessages(int staffId)
        {
            InitializeComponent();
            this.staffId = staffId;
            PopulateClientsComboBox();
            cmb.SelectedIndexChanged += Cmb_SelectedIndexChanged;
            msgtxtbx.Text = "Enter your message here";
            msgtxtbx.Tag = "Enter your message here";
            msgtxtbx.ForeColor = SystemColors.GrayText;
            msgtxtbx.GotFocus += TextBox_GotFocus;
            msgtxtbx.LostFocus += TextBox_LostFocus;
            LoadClientResponse();
        }

        private void LoadClientResponse()
        {
            int clientId = GetSelectedClientId();

            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;"))
                {
                    connection.Open();
                    string query = "SELECT message FROM message WHERE client_id = @ClientId AND staff_id IS NULL";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ClientId", clientId);
                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            responsetxtbx.ForeColor = SystemColors.WindowText;
                            responsetxtbx.Text = result.ToString();
                        }
                        else
                        {
                            responsetxtbx.Text = "Client message goes here";
                            responsetxtbx.Tag = "Client message goes here";
                            responsetxtbx.ForeColor = SystemColors.GrayText;
                            responsetxtbx.GotFocus += TextBox_GotFocus;
                            responsetxtbx.LostFocus += TextBox_LostFocus;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading response: " + ex.Message);
            }
        }

        private void PopulateClientsComboBox()
        {
            cmb.Items.Clear();

            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;"))
                {
                    connection.Open();
                    string query = "SELECT client_id, name FROM client"; 
                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int clientId = reader.GetInt32(0);
                            string clientName = reader.GetString(1);
                            cmb.Items.Add($"{clientName} (ID: {clientId})");

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading clients: " + ex.Message);
            }
        }

        private void sendbtn_Click(object sender, EventArgs e)
        {
            int clientId = GetSelectedClientId();
            string message = msgtxtbx.Text.Trim();

            if (clientId == 0)
            {
                MessageBox.Show("Please select a client.");
                return;
            }

            if (message == "Enter your message here")
            {
                MessageBox.Show("Please enter a message.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;"))
                {
                    connection.Open();

                    string updateQuery = "UPDATE message SET message = @Message, staff_id = @StaffId WHERE client_id = @ClientId AND staff_id IS NULL";

                    string insertQuery = "INSERT INTO message (message, client_id, staff_id) VALUES (@Message, @ClientId, @StaffId)";

                    string selectQuery = "SELECT 1 FROM message WHERE client_id = @ClientId AND staff_id IS NULL";

                    using (SqlCommand command = new SqlCommand(selectQuery, connection))
                    {
                        command.Parameters.AddWithValue("@ClientId", clientId);
                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            command.CommandText = updateQuery;
                        }
                        else
                        {
                            command.CommandText = insertQuery;
                        }

                        command.Parameters.Clear(); 
                        command.Parameters.AddWithValue("@ClientId", clientId);
                        command.Parameters.AddWithValue("@StaffId", staffId);
                        command.Parameters.AddWithValue("@Message", message);
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Message sent successfully.");
                msgtxtbx.Clear();
                responsetxtbx.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error sending message: " + ex.Message);
            }
        }



        private int GetSelectedClientId()
        {
            if (cmb.SelectedItem != null)
            {
                string selectedItem = cmb.SelectedItem.ToString();
                int clientIdStartIndex = selectedItem.LastIndexOf("(ID: ") + 5;
                int clientIdEndIndex = selectedItem.LastIndexOf(")");
                string clientIdStr = selectedItem.Substring(clientIdStartIndex, clientIdEndIndex - clientIdStartIndex);
                if (int.TryParse(clientIdStr, out int clientId))
                {
                    return clientId;
                }
            }
            return 0; 
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            staffdashboard s = new staffdashboard(staffId);
            s.Show();
            this.Hide();
        }
        private void Cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadClientResponse(); 
        }
        private void TextBox_GotFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (textBox.Text == textBox.Tag.ToString())
            {
                textBox.Text = "";
                textBox.ForeColor = SystemColors.WindowText;
            }

        }

        private void TextBox_LostFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = textBox.Tag.ToString();
                textBox.ForeColor = SystemColors.GrayText;

            }
        }

    }
}
