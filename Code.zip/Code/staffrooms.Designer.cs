﻿namespace HotelManagementSystem
{
    partial class rooms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.roomnumbertextbox = new System.Windows.Forms.TextBox();
            this.addbtn = new System.Windows.Forms.Button();
            this.deletebtn = new System.Windows.Forms.Button();
            this.editbtn = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.viewcombobox = new ReaLTaiizor.Controls.PoisonComboBox();
            this.typecombobox = new ReaLTaiizor.Controls.PoisonComboBox();
            this.busyradiobutton = new System.Windows.Forms.RadioButton();
            this.freeradiobutton = new System.Windows.Forms.RadioButton();
            this.close_button = new System.Windows.Forms.Button();
            this.datagridview = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.datagridview)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Room Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label2.Location = new System.Drawing.Point(12, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Status";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label3.Location = new System.Drawing.Point(12, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "View";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label4.Location = new System.Drawing.Point(12, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Type";
            // 
            // roomnumbertextbox
            // 
            this.roomnumbertextbox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.roomnumbertextbox.Location = new System.Drawing.Point(162, 12);
            this.roomnumbertextbox.Multiline = true;
            this.roomnumbertextbox.Name = "roomnumbertextbox";
            this.roomnumbertextbox.Size = new System.Drawing.Size(194, 29);
            this.roomnumbertextbox.TabIndex = 4;
            // 
            // addbtn
            // 
            this.addbtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.addbtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addbtn.ForeColor = System.Drawing.SystemColors.Window;
            this.addbtn.Location = new System.Drawing.Point(16, 201);
            this.addbtn.Name = "addbtn";
            this.addbtn.Size = new System.Drawing.Size(109, 45);
            this.addbtn.TabIndex = 20;
            this.addbtn.Text = "Add";
            this.addbtn.UseVisualStyleBackColor = false;
            this.addbtn.Click += new System.EventHandler(this.addbtn_Click);
            // 
            // deletebtn
            // 
            this.deletebtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.deletebtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deletebtn.ForeColor = System.Drawing.SystemColors.Window;
            this.deletebtn.Location = new System.Drawing.Point(247, 201);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(109, 45);
            this.deletebtn.TabIndex = 21;
            this.deletebtn.Text = "Delete";
            this.deletebtn.UseVisualStyleBackColor = false;
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // editbtn
            // 
            this.editbtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.editbtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editbtn.ForeColor = System.Drawing.SystemColors.Window;
            this.editbtn.Location = new System.Drawing.Point(131, 201);
            this.editbtn.Name = "editbtn";
            this.editbtn.Size = new System.Drawing.Size(109, 45);
            this.editbtn.TabIndex = 22;
            this.editbtn.Text = "Edit";
            this.editbtn.UseVisualStyleBackColor = false;
            this.editbtn.Click += new System.EventHandler(this.editbtn_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.SystemColors.Highlight;
            this.linkLabel1.Location = new System.Drawing.Point(134, 262);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(222, 23);
            this.linkLabel1.TabIndex = 25;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Back to the main page";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // viewcombobox
            // 
            this.viewcombobox.ForeColor = System.Drawing.SystemColors.Highlight;
            this.viewcombobox.FormattingEnabled = true;
            this.viewcombobox.ItemHeight = 23;
            this.viewcombobox.Items.AddRange(new object[] {
            "Sea",
            "Mountain",
            "Garden",
            "Pool"});
            this.viewcombobox.Location = new System.Drawing.Point(162, 109);
            this.viewcombobox.Name = "viewcombobox";
            this.viewcombobox.Size = new System.Drawing.Size(194, 29);
            this.viewcombobox.TabIndex = 31;
            this.viewcombobox.UseSelectable = true;
            // 
            // typecombobox
            // 
            this.typecombobox.ForeColor = System.Drawing.SystemColors.Highlight;
            this.typecombobox.FormattingEnabled = true;
            this.typecombobox.ItemHeight = 23;
            this.typecombobox.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Family",
            "Suite"});
            this.typecombobox.Location = new System.Drawing.Point(162, 61);
            this.typecombobox.Name = "typecombobox";
            this.typecombobox.Size = new System.Drawing.Size(194, 29);
            this.typecombobox.TabIndex = 32;
            this.typecombobox.UseSelectable = true;
            // 
            // busyradiobutton
            // 
            this.busyradiobutton.AutoSize = true;
            this.busyradiobutton.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.busyradiobutton.ForeColor = System.Drawing.SystemColors.Highlight;
            this.busyradiobutton.Location = new System.Drawing.Point(271, 159);
            this.busyradiobutton.Name = "busyradiobutton";
            this.busyradiobutton.Size = new System.Drawing.Size(61, 23);
            this.busyradiobutton.TabIndex = 33;
            this.busyradiobutton.TabStop = true;
            this.busyradiobutton.Text = "Busy";
            this.busyradiobutton.UseVisualStyleBackColor = true;
            // 
            // freeradiobutton
            // 
            this.freeradiobutton.AutoSize = true;
            this.freeradiobutton.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.freeradiobutton.ForeColor = System.Drawing.SystemColors.Highlight;
            this.freeradiobutton.Location = new System.Drawing.Point(162, 159);
            this.freeradiobutton.Name = "freeradiobutton";
            this.freeradiobutton.Size = new System.Drawing.Size(60, 23);
            this.freeradiobutton.TabIndex = 34;
            this.freeradiobutton.TabStop = true;
            this.freeradiobutton.Text = "Free";
            this.freeradiobutton.UseVisualStyleBackColor = true;
            // 
            // close_button
            // 
            this.close_button.BackColor = System.Drawing.SystemColors.Highlight;
            this.close_button.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_button.ForeColor = System.Drawing.SystemColors.Window;
            this.close_button.Location = new System.Drawing.Point(16, 250);
            this.close_button.Name = "close_button";
            this.close_button.Size = new System.Drawing.Size(109, 45);
            this.close_button.TabIndex = 35;
            this.close_button.Text = "LOG OFF";
            this.close_button.UseVisualStyleBackColor = false;
            this.close_button.Click += new System.EventHandler(this.close_button_Click_1);
            // 
            // datagridview
            // 
            this.datagridview.AllowUserToAddRows = false;
            this.datagridview.BackgroundColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.datagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridview.DefaultCellStyle = dataGridViewCellStyle2;
            this.datagridview.Location = new System.Drawing.Point(377, 12);
            this.datagridview.Name = "datagridview";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagridview.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.datagridview.Size = new System.Drawing.Size(447, 283);
            this.datagridview.TabIndex = 36;
            // 
            // rooms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(836, 307);
            this.Controls.Add(this.datagridview);
            this.Controls.Add(this.close_button);
            this.Controls.Add(this.freeradiobutton);
            this.Controls.Add(this.busyradiobutton);
            this.Controls.Add(this.typecombobox);
            this.Controls.Add(this.viewcombobox);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.editbtn);
            this.Controls.Add(this.deletebtn);
            this.Controls.Add(this.addbtn);
            this.Controls.Add(this.roomnumbertextbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Name = "rooms";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "rooms";
            ((System.ComponentModel.ISupportInitialize)(this.datagridview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox roomnumbertextbox;
        private System.Windows.Forms.Button addbtn;
        private System.Windows.Forms.Button deletebtn;
        private System.Windows.Forms.Button editbtn;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private ReaLTaiizor.Controls.PoisonComboBox viewcombobox;
        private ReaLTaiizor.Controls.PoisonComboBox typecombobox;
        private System.Windows.Forms.RadioButton busyradiobutton;
        private System.Windows.Forms.RadioButton freeradiobutton;
        private System.Windows.Forms.Button close_button;
        private System.Windows.Forms.DataGridView datagridview;
    }
}