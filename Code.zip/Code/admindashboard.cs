﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace HotelManagementSystem
{
    public partial class admindashboard : Form
    {
        public admindashboard()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;");
        SqlCommand cmd = new SqlCommand();

       

        private void admindashboard_Load(object sender, EventArgs e)
        {
        }
       

        private void button2_Click_1(object sender, EventArgs e)
        {
            adminaddstaff a = new adminaddstaff();
            a.Show();
            this.Hide();
        }

       

        private void button4_Click_1(object sender, EventArgs e)
        {
            int reservations = 0;
            try
            {
                string query = "SELECT COUNT(*) AS ReservationsCount FROM reservations";
                SqlCommand command = new SqlCommand(query, con);

                con.Open();
                reservations = (int)command.ExecuteScalar();
                textBox.Text = "The number of reservations in the hotel is " + reservations;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }


        private void button3_Click_1(object sender, EventArgs e)
        {
            adminrequestpage a = new adminrequestpage();
            a.Show();
            this.Hide();
        }

       

        private void close_button_Click_1(object sender, EventArgs e)
        {

            login login = new login();
            login.Show();
            this.Hide();
        }
      

        
        bool sidebarExpand = true;
       

       

       

        private void sidebar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int clients = 0;
            try
            {
                string query = "SELECT COUNT(*) AS ClientsCount FROM client";
                SqlCommand command = new SqlCommand(query, con);

                con.Open();
                clients = (int)command.ExecuteScalar();
                textBox.Text = "The number of clients in the hotel is " + clients;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminaddstaff a = new adminaddstaff();
            a.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int staffs = 0;
            try
            {
                string query = "SELECT COUNT(*) AS StaffsCount FROM staff";
                SqlCommand command = new SqlCommand(query, con);

                con.Open();
                staffs = (int)command.ExecuteScalar();
                textBox.Text = "The number of staffs in the hotel is " + staffs;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            adminrequestpage a = new adminrequestpage();
            a.Show();       
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            int rooms = 0;
            try
            {
                string query = "SELECT COUNT(*) AS FreeRooms FROM room where status ='Free'";
                SqlCommand command = new SqlCommand(query, con);

                con.Open();
                rooms = (int)command.ExecuteScalar();
                textBox.Text = "The number of free rooms in the hotel is " + rooms;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int rooms = 0;
            try
            {
                string query = "SELECT COUNT(*) AS BusyRooms FROM room where status ='Busy'";
                SqlCommand command = new SqlCommand(query, con);

                con.Open();
                rooms = (int)command.ExecuteScalar();
                textBox.Text = "The number of busy rooms in the hotel is " + rooms;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
      
        
    }
}
