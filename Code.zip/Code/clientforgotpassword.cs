﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace HotelManagementSystem
{
    public partial class clientforgotpassword : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;");

        public clientforgotpassword()
        {
            InitializeComponent();
        }

        private void request_button_Click(object sender, EventArgs e)
        {
            string username = usernametextbox.Text;

            if (string.IsNullOrWhiteSpace(username))
            {
                MessageBox.Show("Please enter a username.");
                return;
            }

            try
            {
                con.Open();

                SqlCommand checkRequestCommand = new SqlCommand("SELECT COUNT(*) FROM resetpassword WHERE client_username = @username", con);
                checkRequestCommand.Parameters.AddWithValue("@username", username);
                int existingRequestCount = (int)checkRequestCommand.ExecuteScalar();

                if (existingRequestCount > 0)
                {
                    MessageBox.Show("You already have a password reset request.");
                    return;
                }

                SqlCommand getClientIdCommand = new SqlCommand("SELECT client_id FROM Client WHERE username = @username", con);
                getClientIdCommand.Parameters.AddWithValue("@username", username);
                object clientId = getClientIdCommand.ExecuteScalar();

                if (clientId != null)
                {
                    SqlCommand insertRequestCommand = new SqlCommand("INSERT INTO resetpassword (client_id, client_username, request_time, processed) VALUES (@clientId, @username, GETDATE(), 0)", con);
                    insertRequestCommand.Parameters.AddWithValue("@clientId", (int)clientId);
                    insertRequestCommand.Parameters.AddWithValue("@username", username);
                    insertRequestCommand.ExecuteNonQuery();

                    MessageBox.Show("Password reset request submitted successfully.");
                }
                else
                {
                    MessageBox.Show("Username not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }



        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            login login = new login();
            login.Show();
            this.Hide();
        }

      

    
       

        private void checkbutton_Click(object sender, EventArgs e)
        {
            string username = usernametextbox.Text;

            if (string.IsNullOrWhiteSpace(username))
            {
                MessageBox.Show("Please enter a username.");
                return;
            }

            try
            {
                con.Open();
                SqlCommand checkUsernameCommand = new SqlCommand("SELECT COUNT(*) FROM Client WHERE username = @username", con);
                checkUsernameCommand.Parameters.AddWithValue("@username", username);
                int usernameCount = (int)checkUsernameCommand.ExecuteScalar();

                if (usernameCount > 0)
                {
                    SqlCommand command = new SqlCommand("SELECT processed FROM resetpassword WHERE client_username = @username", con);
                    command.Parameters.AddWithValue("@username", username);
                    object processedValue = command.ExecuteScalar();

                    if (processedValue != null)
                    {
                        bool processed = (bool)processedValue;
                        if (processed)
                        {
                            MessageBox.Show("Password reset request is already processed. You can reset your password.");
                            ClientPasswordReset resetForm = new ClientPasswordReset(username);
                            resetForm.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Password reset request is pending.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("No password reset request found for this username.");
                    }
                }
                else
                {
                    MessageBox.Show("Username does not exist.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
