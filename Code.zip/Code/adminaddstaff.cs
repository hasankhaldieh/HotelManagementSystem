﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.Design.WebControls;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class adminaddstaff : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;");
      

        public adminaddstaff()
        {
            InitializeComponent();
            ViewStaff();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            admindashboard a = new admindashboard();
            a.Show();
            this.Hide();
        }



        private void addbutton_Click(object sender, EventArgs e)
        {
            if (IsInvalidTextBox(nametextbox, "Enter your name") ||
                IsInvalidTextBox(usernametextbox, "Enter your username") ||
                IsInvalidTextBox(passwordtextbox, "Enter your password"))
            {
                return;
            }

            string name = nametextbox.Text.Trim();
            string username = usernametextbox.Text.Trim();
            string password = passwordtextbox.Text.Trim();

            if (!IsValidPassword(password))
            {
                MessageBox.Show("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character");
                return;
            }

            try
            {
                string query = "INSERT INTO [staff] (name, username, password, enabled) VALUES (@name, @username, @password, 'False')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);

                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Added successfully");
                ClearTextBoxes();
                ViewStaff();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private bool IsInvalidTextBox(TextBox textbox, string placeholder)
        {
            if (string.IsNullOrWhiteSpace(textbox.Text) || textbox.Text == placeholder)
            {
                MessageBox.Show($"Enter your {textbox.Tag.ToString().ToLower()}");
                return true;
            }
            return false;
        }

        private bool IsValidPassword(string password)
        {
            return password.Length >= 8 && password.Any(char.IsUpper) && password.Any(char.IsLower) && password.Any(char.IsDigit) && password.Any(c => !char.IsLetterOrDigit(c));
        }

        private void ClearTextBoxes()
        {
            nametextbox.Clear();
            usernametextbox.Clear();
            passwordtextbox.Clear();
        }

        private void TextBox_GotFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (textBox.Text == textBox.Tag.ToString())
            {
                textBox.Text = "";
                textBox.ForeColor = SystemColors.WindowText;
            }
        }

        private void TextBox_LostFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = textBox.Tag.ToString();
                textBox.ForeColor = SystemColors.GrayText;
            }
        }

        private void adminaddstaff_Load(object sender, EventArgs e)
        {
            SetPlaceholderText(nametextbox, "Enter your name");
            SetPlaceholderText(usernametextbox, "Enter your username");
            SetPlaceholderText(passwordtextbox, "Enter your password");
        }

        private void SetPlaceholderText(TextBox textBox, string placeholder)
        {
            textBox.Text = placeholder;
            textBox.Tag = placeholder;
            textBox.ForeColor = SystemColors.GrayText;
            textBox.GotFocus += TextBox_GotFocus;
            textBox.LostFocus += TextBox_LostFocus;
        }

        private void close_button_Click_1(object sender, EventArgs e)
        {

            login login = new login();
            login.Show();
            this.Hide();
        }

       private void ViewStaff()
        {
            try
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;"))
                {
                    string query = "SELECT staff_id AS 'Staff Number', name AS 'Staff Name', enabled AS 'Enabled?' FROM staff";

                    SqlDataAdapter adapter = new SqlDataAdapter(query,con);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgv.DataSource = dt;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void enablebtn_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count > 0)
            {
                int staffId = Convert.ToInt32(dgv.SelectedRows[0].Cells["Staff Number"].Value);
                UpdateStaffStatus(staffId,true);
            }
            else
            {
                MessageBox.Show("Please select a staff");
            }
        }

        private void disablebtn_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count > 0)
            {
                int staffId = Convert.ToInt32(dgv.SelectedRows[0].Cells["Staff Number"].Value);
                UpdateStaffStatus(staffId, false);
            }
            else
            {
                MessageBox.Show("Please select a staff");
            }
        }
        private void UpdateStaffStatus(int staffId,bool enabled)
        {
            try
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;"))
                {
                    string query = "UPDATE staff set enabled = @enabled where staff_id = @staffId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@enabled", enabled);
                    cmd.Parameters.AddWithValue("@staffId", staffId);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("The staff's status is updated");
                    ViewStaff();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


    }
}
