﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class staffdashboard : Form
    {
        int id;
        public staffdashboard(int sid)
        {
            InitializeComponent();
            this.id = sid;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            rooms r = new rooms(id);
            r.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            staffmessages s = new staffmessages(id);
            s.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            staffreservations s = new staffreservations(id);  
            s.Show();
            this.Hide();
        }

      
        private void button3_Click(object sender, EventArgs e)
        {
            login login = new login();
            login.Show();
            this.Hide();
        }
    }
}
