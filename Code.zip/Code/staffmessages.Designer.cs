﻿namespace HotelManagementSystem
{
    partial class staffmessages
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.responsetxtbx = new System.Windows.Forms.TextBox();
            this.sendbtn = new System.Windows.Forms.Button();
            this.msgtxtbx = new System.Windows.Forms.TextBox();
            this.cmb = new System.Windows.Forms.ComboBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // responsetxtbx
            // 
            this.responsetxtbx.BackColor = System.Drawing.SystemColors.Window;
            this.responsetxtbx.Location = new System.Drawing.Point(12, 89);
            this.responsetxtbx.Multiline = true;
            this.responsetxtbx.Name = "responsetxtbx";
            this.responsetxtbx.ReadOnly = true;
            this.responsetxtbx.Size = new System.Drawing.Size(613, 25);
            this.responsetxtbx.TabIndex = 26;
            // 
            // sendbtn
            // 
            this.sendbtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.sendbtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendbtn.ForeColor = System.Drawing.SystemColors.Window;
            this.sendbtn.Location = new System.Drawing.Point(12, 120);
            this.sendbtn.Name = "sendbtn";
            this.sendbtn.Size = new System.Drawing.Size(107, 45);
            this.sendbtn.TabIndex = 25;
            this.sendbtn.Text = "Send";
            this.sendbtn.UseVisualStyleBackColor = false;
            this.sendbtn.Click += new System.EventHandler(this.sendbtn_Click);
            // 
            // msgtxtbx
            // 
            this.msgtxtbx.Location = new System.Drawing.Point(12, 51);
            this.msgtxtbx.Multiline = true;
            this.msgtxtbx.Name = "msgtxtbx";
            this.msgtxtbx.Size = new System.Drawing.Size(613, 25);
            this.msgtxtbx.TabIndex = 24;
            // 
            // cmb
            // 
            this.cmb.FormattingEnabled = true;
            this.cmb.Location = new System.Drawing.Point(12, 12);
            this.cmb.Name = "cmb";
            this.cmb.Size = new System.Drawing.Size(613, 21);
            this.cmb.TabIndex = 27;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.SystemColors.Highlight;
            this.linkLabel1.Location = new System.Drawing.Point(152, 142);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(222, 23);
            this.linkLabel1.TabIndex = 28;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Back to the main page";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // staffmessages
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(639, 194);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.cmb);
            this.Controls.Add(this.responsetxtbx);
            this.Controls.Add(this.sendbtn);
            this.Controls.Add(this.msgtxtbx);
            this.Name = "staffmessages";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "staffmessages";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox responsetxtbx;
        private System.Windows.Forms.Button sendbtn;
        private System.Windows.Forms.TextBox msgtxtbx;
        private System.Windows.Forms.ComboBox cmb;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}