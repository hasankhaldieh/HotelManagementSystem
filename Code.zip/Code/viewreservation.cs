﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class viewreservation : Form
    {
        private string connectionString = "Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;";
        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private DataTable dataTable;
        int clientId;

        public viewreservation(int clientId)
        {
            InitializeComponent();
            this.clientId = clientId;
            connection = new SqlConnection(connectionString);
            dataTable = new DataTable();
            LoadReservations();
            datagridview.Columns[4].Width = 150;  
        }

        private void LoadReservations()
        {
            try
            {
                connection.Open();
                string query = "SELECT r.reservation_id AS 'Reservation Number', " +
                    "r.room_number AS 'Room Number', " +
                    "ro.type AS 'Room Type', " +
                    "ro.[view] AS 'Room View', " +
                    "r.client_name AS 'Client Name', " +
                    "r.check_in_date AS 'Check In Date', " +
                    "r.check_out_date AS 'Check Out Date', " +
                    "CONCAT('$', r.price) AS 'Reservation Price' " +
                    "FROM reservations r " +
                    "JOIN room ro ON r.room_number = ro.room_number " +
                    "WHERE r.client_id = @clientId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@clientId", clientId);

                    adapter = new SqlDataAdapter(command);
                    dataTable.Clear();
                    adapter.Fill(dataTable);
                    datagridview.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            client c = new client(clientId);
            c.Show();
            this.Hide();
        }
    }
}
