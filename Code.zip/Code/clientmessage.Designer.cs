﻿namespace HotelManagementSystem
{
    partial class clientmessage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.msgtxtbx = new System.Windows.Forms.TextBox();
            this.responsetxtbx = new System.Windows.Forms.TextBox();
            this.close_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.sendbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // msgtxtbx
            // 
            this.msgtxtbx.Location = new System.Drawing.Point(24, 57);
            this.msgtxtbx.Multiline = true;
            this.msgtxtbx.Name = "msgtxtbx";
            this.msgtxtbx.Size = new System.Drawing.Size(741, 25);
            this.msgtxtbx.TabIndex = 0;
            // 
            // responsetxtbx
            // 
            this.responsetxtbx.BackColor = System.Drawing.SystemColors.Window;
            this.responsetxtbx.Location = new System.Drawing.Point(24, 99);
            this.responsetxtbx.Multiline = true;
            this.responsetxtbx.Name = "responsetxtbx";
            this.responsetxtbx.ReadOnly = true;
            this.responsetxtbx.Size = new System.Drawing.Size(741, 25);
            this.responsetxtbx.TabIndex = 23;
            // 
            // close_button
            // 
            this.close_button.BackColor = System.Drawing.SystemColors.Highlight;
            this.close_button.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_button.ForeColor = System.Drawing.SystemColors.Window;
            this.close_button.Location = new System.Drawing.Point(250, 139);
            this.close_button.Name = "close_button";
            this.close_button.Size = new System.Drawing.Size(107, 45);
            this.close_button.TabIndex = 56;
            this.close_button.Text = "LOG OFF";
            this.close_button.UseVisualStyleBackColor = false;
            this.close_button.Click += new System.EventHandler(this.close_button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(20, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(732, 19);
            this.label1.TabIndex = 57;
            this.label1.Text = "Dear client, here you can send a message to the staff requesting for updating you" +
    "r reservations ";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Highlight;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(137, 139);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 45);
            this.button1.TabIndex = 58;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // sendbtn
            // 
            this.sendbtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.sendbtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendbtn.ForeColor = System.Drawing.SystemColors.Window;
            this.sendbtn.Location = new System.Drawing.Point(24, 139);
            this.sendbtn.Name = "sendbtn";
            this.sendbtn.Size = new System.Drawing.Size(107, 45);
            this.sendbtn.TabIndex = 22;
            this.sendbtn.Text = "Send";
            this.sendbtn.UseVisualStyleBackColor = false;
            this.sendbtn.Click += new System.EventHandler(this.sendbtn_Click);
            // 
            // clientmessage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(800, 207);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.close_button);
            this.Controls.Add(this.responsetxtbx);
            this.Controls.Add(this.sendbtn);
            this.Controls.Add(this.msgtxtbx);
            this.Name = "clientmessage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "clientmessage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox msgtxtbx;
        private System.Windows.Forms.Button sendbtn;
        private System.Windows.Forms.TextBox responsetxtbx;
        private System.Windows.Forms.Button close_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}