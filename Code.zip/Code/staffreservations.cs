﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{

    public partial class staffreservations : Form
    {
        private string connectionString = "Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;";
        private SqlConnection connection;
        private SqlCommand command;
        private SqlDataAdapter adapter;
        private DataTable dataTable;
        int id;
        public staffreservations(int sid)
        {
            InitializeComponent();
            connection = new SqlConnection(connectionString);
            dataTable = new DataTable();
            LoadReservations();
            datagridview.CellClick += datagridview_CellClick;
            LoadRoomViews();
            typecombobox.SelectedIndexChanged += typecombobox_SelectedIndexChanged;
            viewcombobox.SelectedIndexChanged += viewcombobox_SelectedIndexChanged;
            Timer timer = new Timer();
            timer.Interval = 24 * 60 * 60 * 1000; 
            timer.Start();
            SetRoomStatusFree();
            SetRoomStatusBusy();
            this.id = sid;
            clientnametextbox.TextChanged += txtSearchClient_TextChanged_1;
            dgvClients.CellClick += dgvClients_CellClick;
            datagridview.Columns[4].Width = 150;

        }
        private decimal[,] roomPrices = {
    // Garden  Mountain   Pool  Sea
    {50,    60,   75,      100},  // Single
    {75,    90,   100,     125},  // Double
    {100,   125,  150,     175},  // Family
    {150,   175,  200,     225}   // Suite
};

      

        private void LoadRoomViews()
        {
            try
            {
                connection.Open();
                string query = "SELECT DISTINCT [view] FROM room";
                adapter = new SqlDataAdapter(query, connection);
                DataTable roomViewsTable = new DataTable();
                adapter.Fill(roomViewsTable);
                viewcombobox.Items.Clear();
                foreach (DataRow row in roomViewsTable.Rows)
                {
                    viewcombobox.Items.Add(row["view"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading room views: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void LoadReservations()
        {
            try
            {
                connection.Open();
                string query = "SELECT r.reservation_id AS 'Reservation Number', " +
                               "r.room_number AS 'Room Number', " +
                               "ro.type AS 'Room Type', " +
                               "ro.[view] AS 'Room View', " +
                               "r.client_name AS 'Client Name', " +
                               "r.check_in_date AS 'Check In Date', " +
                               "r.check_out_date AS 'Check Out Date', " +
                               "CONCAT('$', r.price) AS 'Reservation Price' " +
                               "FROM reservations r " +
                               "JOIN room ro ON r.room_number = ro.room_number";
                adapter = new SqlDataAdapter(query, connection);
                dataTable.Clear();
                adapter.Fill(dataTable);
                datagridview.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }


        private void viewcombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRoomType = typecombobox.SelectedItem?.ToString();
            string selectedRoomView = viewcombobox.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedRoomType) || string.IsNullOrEmpty(selectedRoomView))
            {
                return;
            }
            DateTime checkInDate = checkindate.Value;
            DateTime checkOutDate = checkoutdate.Value;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT room_number FROM room WHERE ";

                    if (!string.IsNullOrEmpty(selectedRoomType))
                    {
                        query += "type = @SelectedRoomType";
                    }

                    if (!string.IsNullOrEmpty(selectedRoomView))
                    {
                        query += " AND [view] = @SelectedRoomView";
                    }

                    query += " AND room_number NOT IN (" +
                             "SELECT room_number FROM reservations " +
                             "WHERE (@CheckInDate < check_out_date AND @CheckOutDate > check_in_date))";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        if (!string.IsNullOrEmpty(selectedRoomType))
                        {
                            command.Parameters.AddWithValue("@SelectedRoomType", selectedRoomType);
                        }

                        if (!string.IsNullOrEmpty(selectedRoomView))
                        {
                            command.Parameters.AddWithValue("@SelectedRoomView", selectedRoomView);
                        }

                        command.Parameters.AddWithValue("@CheckInDate", checkInDate);
                        command.Parameters.AddWithValue("@CheckOutDate", checkOutDate);

                        SqlDataReader reader = command.ExecuteReader();
                        roomnumbercombobox.Items.Clear();
                        while (reader.Read())
                        {
                            roomnumbercombobox.Items.Add(reader["room_number"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void typecombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRoomType = typecombobox.SelectedItem?.ToString();
            string selectedRoomView = viewcombobox.SelectedItem?.ToString();

            DateTime checkInDate = checkindate.Value;
            DateTime checkOutDate = checkoutdate.Value;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT room_number FROM room WHERE type = @SelectedRoomType ";

                    if (!string.IsNullOrEmpty(selectedRoomView))
                    {
                        query += " AND [view] = @SelectedRoomView";
                    }

                    query += " AND room_number NOT IN (" +
                             "SELECT room_number FROM reservations " +
                             "WHERE (@CheckInDate < check_out_date AND @CheckOutDate > check_in_date))";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SelectedRoomType", selectedRoomType);

                        if (!string.IsNullOrEmpty(selectedRoomView))
                        {
                            command.Parameters.AddWithValue("@SelectedRoomView", selectedRoomView);
                        }

                        command.Parameters.AddWithValue("@CheckInDate", checkInDate);
                        command.Parameters.AddWithValue("@CheckOutDate", checkOutDate);

                        SqlDataReader reader = command.ExecuteReader();
                        roomnumbercombobox.Items.Clear();
                        while (reader.Read())
                        {
                            roomnumbercombobox.Items.Add(reader["room_number"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }





        private void datagridview_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = datagridview.Rows[e.RowIndex];
                roomnumbercombobox.Text = row.Cells["Room Number"].Value.ToString();
                clientnametextbox.Text = row.Cells["Client Name"].Value.ToString();
                typecombobox.SelectedItem = row.Cells["Room Type"].Value.ToString();
                viewcombobox.SelectedItem = row.Cells["Room View"].Value.ToString();
                checkindate.Value = Convert.ToDateTime(row.Cells["Check In Date"].Value);
                checkoutdate.Value = Convert.ToDateTime(row.Cells["Check Out Date"].Value);
            }
        }

        private void ClearFields()
        {
            roomnumbercombobox.Text = "";
            clientnametextbox.Clear();
            checkindate.Value = DateTime.Now;
            checkoutdate.Value = DateTime.Now;
        }

        private KeyValuePair<int, string> GetClientInfoFromName(string clientName)
        {
            int clientId = -1;
            string clientNameResult = null;
            try
            {
                connection.Open();
                string query = "SELECT client_id, name FROM client WHERE name = @ClientName";
                command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ClientName", clientName);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    clientId = reader.GetInt32(0);
                    clientNameResult = reader.GetString(1);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
            return new KeyValuePair<int, string>(clientId, clientNameResult);
        }


        private void close_button_Click(object sender, EventArgs e)
        {
            login login = new login();
            login.Show();
            this.Hide();
        }
      

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            staffdashboard s = new staffdashboard(id);
            s.Show();
            this.Hide();
        }


        private void MarkRoomAsBusy(SqlConnection connection, string roomNumber )
        {
            try
            {
                    string updateQuery = "UPDATE room SET status = 'Busy' WHERE room_number IN (SELECT room_number FROM reservations WHERE check_in_date = @CurrentDate)";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@CurrentDate", DateTime.Now.Date);
                        updateCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating room status: " + ex.Message);
            }

        }


        private void MarkRoomsAsFree(SqlConnection connection, string roomNumber)
        {
            try
            {
                string updateQuery = "UPDATE room SET status = 'Free' WHERE room_number = @RoomNumber";
                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@RoomNumber", roomNumber);
                    updateCommand.ExecuteNonQuery();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error marking room as free: " + ex.Message);
            }
           
        }

        private void SetRoomStatusFree()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE room SET status = 'Free' WHERE room_number IN (SELECT room_number FROM reservations WHERE check_out_date <= @CurrentDate)";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@CurrentDate", DateTime.Now.Date);
                        updateCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting/expiring reservations: " + ex.Message);
            }
        }

        private void SetRoomStatusBusy()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE room SET status = 'Busy' WHERE room_number IN (SELECT room_number FROM reservations WHERE check_in_date = @CurrentDate)";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@CurrentDate", DateTime.Now.Date);
                        updateCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting/expiring reservations: " + ex.Message);
            }
        }


        private decimal CalculateReservationPrice(int roomNumber, DateTime checkInDate, DateTime checkOutDate)
        {
            decimal price = 0;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT ro.type AS 'Room Type', ro.[view] AS 'Room View' FROM room ro WHERE room_number = @RoomNumber";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@RoomNumber", roomNumber);
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            int roomTypeIndex = typecombobox.FindStringExact(reader["Room Type"].ToString());
                            int roomViewIndex = viewcombobox.FindStringExact(reader["Room View"].ToString());

                            decimal basePrice = roomPrices[roomTypeIndex, roomViewIndex];

                            int duration = (int)(checkOutDate - checkInDate).TotalDays;

                            price = basePrice * duration;
                        }
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error calculating reservation price: " + ex.Message);
            }

            return price;
        }



        private void DeductReservationPriceFromBudget(int clientId, decimal reservationPrice)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE client SET budget = budget - @ReservationPrice WHERE client_id = @ClientId";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@ReservationPrice", reservationPrice);
                        updateCommand.Parameters.AddWithValue("@ClientId", clientId);
                        updateCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deducting reservation price from client's budget: " + ex.Message);
            }
        }


        private void UpdateClientBudget(int clientId, decimal priceDifference)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE client SET budget = budget + @PriceDifference WHERE client_id = @ClientId";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@PriceDifference", priceDifference);
                        updateCommand.Parameters.AddWithValue("@ClientId", clientId);
                        updateCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating client's budget: " + ex.Message);
            }
        }

        private void RefundReservationPriceToBudget(string clientName, decimal reservationPrice)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE client SET budget = budget + @ReservationPrice WHERE name = @ClientName";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@ReservationPrice", reservationPrice);
                        updateCommand.Parameters.AddWithValue("@ClientName", clientName);
                        updateCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error refunding reservation price to client's budget: " + ex.Message);
            }
        }
        private decimal GetClientBudget(int clientId)
        {
            decimal budget = 0;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT budget FROM client WHERE client_id = @ClientId";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ClientId", clientId);
                        object result = command.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            budget = Convert.ToDecimal(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving client budget: " + ex.Message);
            }
            return budget;
        }

        private void addbtn_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(roomnumbercombobox.Text) || string.IsNullOrEmpty(clientnametextbox.Text))
            {
                MessageBox.Show("Please fill all fields!");
                return;
            }

            if (checkindate.Value < DateTime.Now.Date || checkindate.Value >= checkoutdate.Value)
            {
                MessageBox.Show("Check-in date must be greater than the current date and smaller than the check-out date!");
                return;
            }

            var clientInfo = GetClientInfoFromName(clientnametextbox.Text);
            if (clientInfo.Key == -1 || clientInfo.Value == null)
            {
                MessageBox.Show("Error: Client not found.");
                return;
            }

            string roomNumber = roomnumbercombobox.Text;
            DateTime checkInDate = checkindate.Value;
            DateTime checkOutDate = checkoutdate.Value;

            if (IsReservationOverlap(roomNumber, checkInDate, checkOutDate))
            {
                MessageBox.Show("Another reservation already exists for the selected room and overlapping dates. Please select different dates or a different room.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    decimal reservationPrice = CalculateReservationPrice(Convert.ToInt32(roomNumber), checkInDate, checkOutDate);

                    decimal currentBudget = GetClientBudget(clientInfo.Key);

                    decimal newBudget = currentBudget - reservationPrice;

                    if (newBudget < 0)
                    {
                        MessageBox.Show("Unenough budget. Please choose a different room or adjust the reservation.");
                        return;
                    }

                    DeductReservationPriceFromBudget(clientInfo.Key, reservationPrice);

                    string query = "INSERT INTO reservations (room_number, client_id, client_name, check_in_date, check_out_date, price, staff_id) VALUES (@RoomNumber, @ClientId, @ClientName, @CheckInDate, @CheckOutDate, @Price, @StaffId)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@RoomNumber", roomNumber);
                        command.Parameters.AddWithValue("@ClientId", clientInfo.Key);
                        command.Parameters.AddWithValue("@ClientName", clientInfo.Value);
                        command.Parameters.AddWithValue("@CheckInDate", checkInDate.ToString("yyyy-MM-dd"));
                        command.Parameters.AddWithValue("@CheckOutDate", checkOutDate.ToString("yyyy-MM-dd"));
                        command.Parameters.AddWithValue("@Price", reservationPrice);
                        command.Parameters.AddWithValue("@StaffId", id);
                        command.ExecuteNonQuery();
                    }

                    MarkRoomAsBusy(connection, roomNumber);
                    MessageBox.Show("Reservation added successfully!");
                    ClearFields();
                    LoadReservations();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void editbtn_Click_1(object sender, EventArgs e)
        {
            if (datagridview.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a reservation to edit!");
                return;
            }

            DataRowView selectedRow = (DataRowView)datagridview.SelectedRows[0].DataBoundItem;
            int reservationId = Convert.ToInt32(selectedRow["Reservation Number"]);

            if (string.IsNullOrEmpty(roomnumbercombobox.Text) || string.IsNullOrEmpty(clientnametextbox.Text))
            {
                MessageBox.Show("Please fill all fields!");
                return;
            }

            if (checkindate.Value < DateTime.Now.Date || checkindate.Value >= checkoutdate.Value)
            {
                MessageBox.Show("Check-in date must be greater than the current date and smaller than the check-out date!");
                return;
            }

            string existingRoomNumber = selectedRow["Room Number"].ToString();
            var clientInfo = GetClientInfoFromName(clientnametextbox.Text);

            if (clientInfo.Key == -1 || clientInfo.Value == null)
            {
                MessageBox.Show("Error: Client not found.");
                return;
            }

            DateTime checkInDate = checkindate.Value;
            DateTime checkOutDate = checkoutdate.Value;

            if (IsReservationOverlap(roomnumbercombobox.Text, checkInDate, checkOutDate, reservationId))
            {
                MessageBox.Show("Another reservation already exists for the selected room and overlapping dates. Please select different dates or a different room.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    decimal previousReservationPrice = Convert.ToDecimal(selectedRow["Reservation Price"].ToString().Replace("$", ""));

                    decimal newReservationPrice = CalculateReservationPrice(Convert.ToInt32(roomnumbercombobox.Text), checkInDate, checkOutDate);
                    decimal priceDifference = newReservationPrice - previousReservationPrice;
                    decimal currentBudget = GetClientBudget(clientInfo.Key);
                    decimal newBudget = currentBudget + previousReservationPrice - newReservationPrice;
                    if (newBudget < 0)
                    {
                        MessageBox.Show("Unenough budget. Please choose a different room or adjust the reservation.");
                        return;
                    }

                    UpdateClientBudget(clientInfo.Key, previousReservationPrice);
                    DeductReservationPriceFromBudget(clientInfo.Key, newReservationPrice);
                    string query = "UPDATE reservations SET room_number = @RoomNumber, client_id = @ClientId, client_name = @ClientName, check_in_date = @CheckInDate, check_out_date = @CheckOutDate, price = @Price, staff_id = @StaffId WHERE reservation_id = @ReservationId";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@RoomNumber", roomnumbercombobox.Text);
                        command.Parameters.AddWithValue("@ClientId", clientInfo.Key);
                        command.Parameters.AddWithValue("@ClientName", clientInfo.Value);
                        command.Parameters.AddWithValue("@CheckInDate", checkInDate.ToString("yyyy-MM-dd"));
                        command.Parameters.AddWithValue("@CheckOutDate", checkOutDate.ToString("yyyy-MM-dd"));
                        command.Parameters.AddWithValue("@ReservationId", reservationId);
                        command.Parameters.AddWithValue("@Price", newReservationPrice);
                        command.Parameters.AddWithValue("@StaffId", id);
                        command.ExecuteNonQuery();
                    }

                    MarkRoomsAsFree(connection, existingRoomNumber);
                    MarkRoomAsBusy(connection, roomnumbercombobox.Text);

                    MessageBox.Show("Reservation updated successfully!");
                    ClearFields();
                    LoadReservations();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }



        private void deletebtn_Click_1(object sender, EventArgs e)
        {
            if (datagridview.SelectedRows.Count > 0)
            {
                if (MessageBox.Show("Are you sure you want to delete this reservation?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataRowView selectedRow = (DataRowView)datagridview.SelectedRows[0].DataBoundItem;
                    int reservationId = Convert.ToInt32(selectedRow["Reservation Number"]);

                    SqlConnection connection = new SqlConnection(connectionString);
                    try
                    {
                        connection.Open();

                        string roomNumber = selectedRow["Room Number"].ToString();

                        decimal reservationPrice = Convert.ToDecimal(selectedRow["Reservation Price"].ToString().Replace("$", ""));


                        var clientInfo = GetClientInfoFromName(selectedRow["Client Name"].ToString());

                        RefundReservationPriceToBudget(selectedRow["Client Name"].ToString(), reservationPrice);

                        string query = "DELETE FROM reservations WHERE reservation_id = @ReservationId";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@ReservationId", reservationId);
                            command.ExecuteNonQuery();
                        }
                        MarkRoomsAsFree(connection, roomNumber);
                        MessageBox.Show("Reservation deleted successfully!");
                        LoadReservations();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (connection.State != ConnectionState.Closed)
                            connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a reservation to delete!");
            }
        }



        private void FilterClients(string searchText)
        {
            try
            {
                connection.Open();
                string query = "SELECT client_id as 'CLient Number',name as 'Client Name' FROM client WHERE name LIKE @SearchText";
                adapter = new SqlDataAdapter(query, connection);
                adapter.SelectCommand.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");
                DataTable clientsTable = new DataTable();
                adapter.Fill(clientsTable);
                dgvClients.DataSource = clientsTable;

              
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error searching clients: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }




        private void txtSearchClient_TextChanged_1(object sender, EventArgs e)
        {
            string searchText = clientnametextbox.Text;
            FilterClients(searchText);
        }

        private void dgvClients_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvClients.SelectedRows.Count > 0)
            {
                DataRowView selectedRow = (DataRowView)dgvClients.SelectedRows[0].DataBoundItem;
                string name = selectedRow["Client Name"].ToString();
                clientnametextbox.Text = Convert.ToString(name);
            }
        }

        private bool IsReservationOverlap(string roomNumber, DateTime checkInDate, DateTime checkOutDate, int reservationId = -1)
        {
            try
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM reservations WHERE room_number = @RoomNumber AND reservation_id != @ReservationId AND (@CheckInDate < check_out_date AND @CheckOutDate > check_in_date)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RoomNumber", roomNumber);
                    command.Parameters.AddWithValue("@CheckInDate", checkInDate);
                    command.Parameters.AddWithValue("@CheckOutDate", checkOutDate);
                    command.Parameters.AddWithValue("@ReservationId", reservationId);
                    int overlapCount = (int)command.ExecuteScalar();
                    return overlapCount > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking reservation overlap: " + ex.Message);
                return true; 
            }
            finally
            {
                connection.Close();
            }
        }

       
    }
}

