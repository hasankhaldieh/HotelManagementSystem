﻿using ReaLTaiizor.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class rooms : Form
    {
        private string connectionString = "Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;";
        private SqlDataAdapter adapter;
        private DataTable dataTable;
        int id;
        public rooms(int id)
        {
            this.id = id;
            InitializeComponent();
            PopulateDataGridView();
            datagridview.CellClick += DataGridView_CellClick;
        }

        private void PopulateDataGridView()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT room_number as [Room Number], type as Type, [view] as [View], status as Status FROM room";

                adapter = new SqlDataAdapter(query, connection);
                SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                dataTable = new DataTable();
                adapter.Fill(dataTable);
                datagridview.DataSource = dataTable;

            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            staffdashboard s = new staffdashboard(id);
            s.Show();   
            this.Hide();
        }

        private void addbtn_Click(object sender, EventArgs e)
        {
            if (AllFieldsFilled())
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO room (room_number, type, [view], status) VALUES (@room_number, @type, @view, @status)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@room_number", roomnumbertextbox.Text);
                    command.Parameters.AddWithValue("@type", typecombobox.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@view", viewcombobox.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@status", (freeradiobutton.Checked ? "Free" : "Busy"));

                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Room added successfully");
                }

                PopulateDataGridView();
            }
            else
            {
                MessageBox.Show("Please fill in all fields before adding.");
            }
        }

        private void editbtn_Click(object sender, EventArgs e)
        {
            if (AllFieldsFilled())
            {
                int rowIndex = datagridview.CurrentCell.RowIndex;
                string roomId = datagridview.Rows[rowIndex].Cells[0].Value.ToString();

                if (!string.IsNullOrEmpty(roomId))
                {
                    if (RoomHasReservations(roomId) && (freeradiobutton.Checked))
                    {
                        MessageBox.Show("Cannot set the room to 'Free' status because it has associated reservations.");
                    }
                    else
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            string query = "UPDATE room SET room_number=@room_number, type=@type, [view]=@view, status=@status WHERE room_number=@roomId";
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@room_number", roomnumbertextbox.Text);
                            command.Parameters.AddWithValue("@type", typecombobox.SelectedItem.ToString());
                            command.Parameters.AddWithValue("@view", viewcombobox.SelectedItem.ToString());
                            command.Parameters.AddWithValue("@status", (freeradiobutton.Checked ? "Free" : "Busy"));
                            command.Parameters.AddWithValue("@roomId", roomId);

                            connection.Open();
                            command.ExecuteNonQuery();
                            MessageBox.Show("Room edited successfully");
                        }

                        PopulateDataGridView();
                    }
                }
                else
                {
                    MessageBox.Show("Please select a room to edit.");
                }
            }
            else
            {
                MessageBox.Show("Please fill in all fields before editing.");
            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            int rowIndex = datagridview.CurrentCell.RowIndex;
            string roomId = datagridview.Rows[rowIndex].Cells[0].Value.ToString();

            if (!string.IsNullOrEmpty(roomId))
            {
                if (RoomHasReservations(roomId))
                {
                    MessageBox.Show("Cannot delete the room because it has associated reservations.");
                }
                else
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        string query = "DELETE FROM room WHERE room_number=@roomId";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@roomId", roomId);

                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Room deleted successfully");
                    }

                    PopulateDataGridView();
                }
            }
            else
            {
                MessageBox.Show("Please select a room to delete.");
            }
        }


        private bool RoomHasReservations(string roomId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT COUNT(*) FROM reservations WHERE room_number = @roomId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@roomId", roomId);
                connection.Open();
                int reservationCount = (int)command.ExecuteScalar();
                return reservationCount > 0;
            }
        }
        private bool AllFieldsFilled()
        {
            return !string.IsNullOrWhiteSpace(roomnumbertextbox.Text) &&
                   typecombobox.SelectedItem != null &&
                   viewcombobox.SelectedItem != null &&
                   (freeradiobutton.Checked || busyradiobutton.Checked);
        }
        private void DataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = datagridview.Rows[e.RowIndex];
                roomnumbertextbox.Text = row.Cells["Room Number"].Value.ToString();
                typecombobox.SelectedItem = row.Cells["Type"].Value.ToString();
                viewcombobox.SelectedItem = row.Cells["View"].Value.ToString();
                string status = row.Cells["Status"].Value.ToString();
                freeradiobutton.Checked = (status == "Free");
                busyradiobutton.Checked = (status == "Busy");
            }
        }

        private void close_button_Click_1(object sender, EventArgs e)
        {

            login login = new login();
            login.Show();
            this.Hide();
        }
    }
}
