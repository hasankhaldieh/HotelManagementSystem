﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace HotelManagementSystem
{
    public partial class confirmemail : Form
    {
        private SqlConnection connection = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;");
        int client_id;
        String randomCode;
        public static String to;
        public confirmemail(int clientId)
        {
            InitializeComponent();
            client_id = clientId;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            login l = new login();
            l.Show();
            this.Hide();    
        }

        private void sendbtn_Click(object sender, EventArgs e)
        {
            if (emailTextBox.Text == "")
            {
                MessageBox.Show("Enter your email address");
                return;
            }
            String from, pass, messageBody;
            Random rand = new Random();
            randomCode = (rand.Next(999999)).ToString();
            MailMessage message = new MailMessage();
            to = (emailTextBox.Text).ToString();
            from = "hasankld68@gmail.com";
            pass = "oppgiieplvaavnea";
            messageBody = "Your account activation code is " + randomCode;
            message.To.Add(to);
            message.From = new MailAddress(from);
            message.Body = messageBody;
            message.Subject = "Account Activation Code";
            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            smtp.EnableSsl = true;
            smtp.Port = 587;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Credentials = new NetworkCredential(from, pass);

            try
            {
                smtp.Send(message);
                MessageBox.Show("Code Sent Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void verify_button_Click(object sender, EventArgs e)
        {
            if (randomCode == codeTextBox.Text)
            {
                to = emailTextBox.Text;
                this.Hide();
                string query = "UPDATE client SET verified = @vr WHERE client_id = @client_id";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@vr", "True");
                    command.Parameters.AddWithValue("@client_id", client_id);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                MessageBox.Show("Account Activated Successfully");
                client c = new client(client_id);
                c.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong Code");
            }
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            login l = new login();
            l.Show();
            this.Hide();
        }
    }
}
