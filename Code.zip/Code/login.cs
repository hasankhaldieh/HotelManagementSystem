﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.ClientServices;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;


namespace HotelManagementSystem
{
    public partial class login : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;");

        public login()
        {
            InitializeComponent();

        }

        private void login_button_Click(object sender, EventArgs e)
        {
            if (username_textbox.Text == "Enter your username")
            {
                MessageBox.Show("Enter your username");
                return;
            }
            else if (password_textbox.Text == "Enter your password")
            {
                MessageBox.Show("Enter your password");
                return;
            }

            try
            {
                string username = username_textbox.Text;
                string password = password_textbox.Text;

                SqlCommand cmdAdmin = new SqlCommand("SELECT * FROM admin WHERE username = @username AND password = @password", con);
                cmdAdmin.Parameters.AddWithValue("@username", username);
                cmdAdmin.Parameters.AddWithValue("@password", password);

                SqlCommand cmdStaff = new SqlCommand("SELECT * FROM staff WHERE username = @username AND password = @password", con);
                cmdStaff.Parameters.AddWithValue("@username", username);
                cmdStaff.Parameters.AddWithValue("@password", password);

                SqlCommand cmdClient = new SqlCommand("SELECT * FROM client WHERE username = @username AND password = @password", con);
                cmdClient.Parameters.AddWithValue("@username", username);
                cmdClient.Parameters.AddWithValue("@password", password);

                con.Open();
                DataTable adminTable = new DataTable();
                DataTable staffTable = new DataTable();
                DataTable clientTable = new DataTable();
                SqlDataAdapter adminAdapter = new SqlDataAdapter(cmdAdmin);
                adminAdapter.Fill(adminTable);
                SqlDataAdapter staffAdapter = new SqlDataAdapter(cmdStaff);
                staffAdapter.Fill(staffTable);
                SqlDataAdapter clientAdapter = new SqlDataAdapter(cmdClient);
                clientAdapter.Fill(clientTable);

                if (adminTable.Rows.Count > 0)
                {
                    admindashboard adminForm = new admindashboard();
                    adminForm.Show();
                    this.Hide();
                }
                else if (staffTable.Rows.Count > 0)
                {
                    bool isEnabled = Convert.ToBoolean(staffTable.Rows[0]["enabled"]);

                    if (isEnabled)
                    {
                        int staffId = Convert.ToInt32(staffTable.Rows[0]["staff_Id"]);
                        staffdashboard s = new staffdashboard(staffId);
                        s.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Your account is disabled. Please contact the administrator for assistance.");
                    }
                }

                else if (clientTable.Rows.Count > 0)
                {
                    if (CheckAccount())
                    {
                        int clientId = Convert.ToInt32(clientTable.Rows[0]["client_id"]);
                        client c = new client(clientId);
                        c.Show();
                        this.Hide();
                    }
                    else
                    {

                        int clientId = Convert.ToInt32(clientTable.Rows[0]["client_id"]);
                        this.Hide();
                        MessageBox.Show("You have to activate your account to access the system.");
                        confirmemail v = new confirmemail(clientId);
                        v.Show();
                        this.Hide();
                       
                    }
                   
                }
                else
                {
                    MessageBox.Show("Wrong Username or Password");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }


        private void close_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            clientsignup signupForm = new clientsignup();
            signupForm.Show();
            this.Hide();
        }

        private void TextBox_GotFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (textBox.Text == textBox.Tag.ToString())
            {
                textBox.Text = "";
                textBox.ForeColor = SystemColors.WindowText;
            }
            if (textBox.Name == "password_textbox")
            {
                textBox.PasswordChar = '*';
            }
        }

        private void TextBox_LostFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = textBox.Tag.ToString();
                textBox.ForeColor = SystemColors.GrayText;
                if (textBox.Name == "password_textbox")
                {
                    textBox.PasswordChar = '\0';
                }
            }
        }


        private void login_Load(object sender, EventArgs e)
        {
            username_textbox.Text = "Enter your username";
            username_textbox.Tag = "Enter your username";
            username_textbox.ForeColor = SystemColors.GrayText;
            username_textbox.GotFocus += TextBox_GotFocus;
            username_textbox.LostFocus += TextBox_LostFocus;

            password_textbox.Text = "Enter your password";
            password_textbox.Tag = "Enter your password";
            password_textbox.ForeColor = SystemColors.GrayText;
            password_textbox.GotFocus += TextBox_GotFocus;
            password_textbox.LostFocus += TextBox_LostFocus;
           
        }

        private void password_textbox_TextChanged(object sender, EventArgs e)
        {
            password_textbox.BackColor = Color.White;
            panel2.BackColor = Color.White;
            username_textbox.BackColor = SystemColors.Control;
            panel1.BackColor = SystemColors.Control;
        }

        private void username_textbox_TextChanged(object sender, EventArgs e)
        {
            username_textbox.BackColor = Color.White;
            panel1.BackColor = Color.White;
            panel2.BackColor = SystemColors.Control;
            password_textbox.BackColor = SystemColors.Control;
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            clientforgotpassword form = new clientforgotpassword();
            form.Show();
            this.Hide();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            confirmemail c = new confirmemail(clientId);
            c.Show();
            this.Hide();
        }

        private void password_textbox_TextChanged_1(object sender, EventArgs e)
        {
            password_textbox.PasswordChar.ToString();
        }
        bool IsVerified;
        int clientId = -1;
        public bool CheckAccount()
        {
            string username = username_textbox.Text;
            string password = password_textbox.Text;
            string verified = "";
            using (con)
            {
                using (var command = new SqlCommand())
                {
                    command.Connection = con;
                    command.CommandText = @"SELECT verified, client_id  
                                     FROM 
                                     client
                                     WHERE username = @username AND password = @password";
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", password);

                     using (var reader = command.ExecuteReader())
                     {
                         if (reader.Read())
                         {
                             
                             verified = reader["verified"].ToString();
                            clientId = Convert.ToInt32(reader["client_id"]);
                            if (verified=="True")
                            {
                                IsVerified = true;
                            }
                            else
                            {
                                IsVerified = false;
                            }
                         }
                        
                     }
                        

                }
               
            }

            return IsVerified;
        }

    }
}