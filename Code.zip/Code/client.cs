﻿using Humanizer;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class client : Form
    {
        private string connectionString = "Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;";
        private SqlConnection connection;
        private SqlCommand command;
        private SqlDataAdapter adapter;
        private DataTable dataTable;
        int clientId;
        string[] roomTypes;
        string[] roomViews;
        public client(int clientid)
        {
            InitializeComponent();
            connection = new SqlConnection(connectionString);
            dataTable = new DataTable();
            LoadRoomViews();
            SetRoomStatusFree();
            SetRoomStatusBusy();
            typecombobox.SelectedIndexChanged += typecombobox_SelectedIndexChanged;
            viewcombobox.SelectedIndexChanged += viewcombobox_SelectedIndexChanged;
            Timer timer = new Timer();
            timer.Interval = 24 * 60 * 60 * 1000; 
            timer.Start();
            this.clientId = clientid;
            getBudget();
            roomTypes = GetRoomTypes(); 
            roomViews = GetRoomViews();
            LoadRoomPrices();
            

        }

        private decimal[,] roomPrices = {
    // Garden  Mountain   Pool      Sea
        {50,    60,        75,      100},  // Single
        {75,    90,       100,      125},  // Double
        {100,   125,      150,      175},  // Family
        {150,   175,      200,      225}   // Suite
                                        };


        private decimal[,] roomPricess = {
       
        {75,    90,       100,      125},  // Double
         {100,   125,      150,      175},  // Family
        {50,    60,        75,      100},  // Single
        {150,   175,      200,      225}   // Suite
                                        };



        private string[] GetRoomTypes()
        {
            List<string> roomTypes = new List<string>();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT DISTINCT type FROM room";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string type = reader["type"].ToString();
                            roomTypes.Add(type);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching room types: " + ex.Message);
            }

            return roomTypes.ToArray();
        }

        private string[] GetRoomViews()
        {
            List<string> roomViews = new List<string>();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT DISTINCT [view] FROM room";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string view = reader["view"].ToString();
                            roomViews.Add(view);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching room views: " + ex.Message);
            }

            return roomViews.ToArray();
        }



        private void LoadRoomPrices()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT ro.type AS 'Room Type', ro.[view] AS 'Room View' FROM room ro";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataTable.Columns.Add("Price Per Night", typeof(string));

                        foreach (DataRow row in dataTable.Rows)
                        {
                            string roomType = row["Room Type"].ToString();
                            string roomView = row["Room View"].ToString();

                            int roomTypeIndex = Array.IndexOf(roomTypes, roomType);
                            int roomViewIndex = Array.IndexOf(roomViews, roomView);

                            if (roomTypeIndex != -1 && roomViewIndex != -1)
                            {
                                decimal basePrice = roomPricess[roomTypeIndex, roomViewIndex];
                                row["Price Per Night"] = basePrice.ToString("C"); 
                            }
                            else
                            {
                                row["Price Per Night"] = DBNull.Value;
                            }
                        }

                        dgv.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading room prices: " + ex.Message);
            }
        }

        private void viewcombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRoomType = typecombobox.SelectedItem?.ToString();
            string selectedRoomView = viewcombobox.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedRoomType) || string.IsNullOrEmpty(selectedRoomView))
            {
                return;
            }
            DateTime checkInDate = checkindate.Value;
            DateTime checkOutDate = checkoutdate.Value;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT room_number FROM room WHERE ";

                    if (!string.IsNullOrEmpty(selectedRoomType))
                    {
                        query += "type = @SelectedRoomType";
                    }

                    if (!string.IsNullOrEmpty(selectedRoomView))
                    {
                        query += " AND [view] = @SelectedRoomView";
                    }

                    query += " AND room_number NOT IN (" +
                             "SELECT room_number FROM reservations " +
                             "WHERE (@CheckInDate < check_out_date AND @CheckOutDate > check_in_date))";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        if (!string.IsNullOrEmpty(selectedRoomType))
                        {
                            command.Parameters.AddWithValue("@SelectedRoomType", selectedRoomType);
                        }

                        if (!string.IsNullOrEmpty(selectedRoomView))
                        {
                            command.Parameters.AddWithValue("@SelectedRoomView", selectedRoomView);
                        }

                        command.Parameters.AddWithValue("@CheckInDate", checkInDate);
                        command.Parameters.AddWithValue("@CheckOutDate", checkOutDate);

                        SqlDataReader reader = command.ExecuteReader();
                        roomnumbercombobox.Items.Clear();
                        while (reader.Read())
                        {
                            roomnumbercombobox.Items.Add(reader["room_number"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void typecombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRoomType = typecombobox.SelectedItem?.ToString();
            string selectedRoomView = viewcombobox.SelectedItem?.ToString();

            DateTime checkInDate = checkindate.Value;
            DateTime checkOutDate = checkoutdate.Value;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT room_number FROM room WHERE type = @SelectedRoomType ";

                    if (!string.IsNullOrEmpty(selectedRoomView))
                    {
                        query += " AND [view] = @SelectedRoomView";
                    }

                    query += " AND room_number NOT IN (" +
                             "SELECT room_number FROM reservations " +
                             "WHERE (@CheckInDate < check_out_date AND @CheckOutDate > check_in_date))";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SelectedRoomType", selectedRoomType);

                        if (!string.IsNullOrEmpty(selectedRoomView))
                        {
                            command.Parameters.AddWithValue("@SelectedRoomView", selectedRoomView);
                        }

                        command.Parameters.AddWithValue("@CheckInDate", checkInDate);
                        command.Parameters.AddWithValue("@CheckOutDate", checkOutDate);

                        SqlDataReader reader = command.ExecuteReader();
                        roomnumbercombobox.Items.Clear();
                        while (reader.Read())
                        {
                            roomnumbercombobox.Items.Add(reader["room_number"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void LoadRoomViews()
        {
            try
            {
                connection.Open();
                string query = "SELECT DISTINCT [view] FROM room";
                adapter = new SqlDataAdapter(query, connection);
                DataTable roomViewsTable = new DataTable();
                adapter.Fill(roomViewsTable);
                viewcombobox.Items.Clear();
                foreach (DataRow row in roomViewsTable.Rows)
                {
                    viewcombobox.Items.Add(row["view"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading room views: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        private void MarkRoomAsBusy(SqlConnection connection, string roomNumber)
        {
            try
            {
                string updateQuery = "UPDATE room SET status = 'Busy' WHERE room_number IN (SELECT room_number FROM reservations WHERE check_in_date = @CurrentDate)";
                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@CurrentDate", DateTime.Now.Date);
                    updateCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating room status: " + ex.Message);
            }

        }


        private void MarkRoomsAsFree(SqlConnection connection, string roomNumber)
        {
            try
            {
                string updateQuery = "UPDATE room SET status = 'Free' WHERE room_number = @RoomNumber";
                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@RoomNumber", roomNumber);
                    updateCommand.ExecuteNonQuery();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error marking room as free: " + ex.Message);
            }

        }

        private void SetRoomStatusFree()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE room SET status = 'Free' WHERE room_number IN (SELECT room_number FROM reservations WHERE check_out_date <= @CurrentDate)";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@CurrentDate", DateTime.Now.Date);
                        updateCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting/expiring reservations: " + ex.Message);
            }
        }

        private void SetRoomStatusBusy()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE room SET status = 'Busy' WHERE room_number IN (SELECT room_number FROM reservations WHERE check_in_date = @CurrentDate)";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@CurrentDate", DateTime.Now.Date);
                        updateCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting/expiring reservations: " + ex.Message);
            }
        }

        private void addbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(roomnumbercombobox.Text))
            {
                MessageBox.Show("Please fill all fields!");
                return;
            }

            if (checkindate.Value < DateTime.Now.Date || checkindate.Value >= checkoutdate.Value)
            {
                MessageBox.Show("Check-in date must be greater than the current date and smaller than the check-out date!");
                return;
            }

            string roomNumber = roomnumbercombobox.Text;
            DateTime checkInDate = checkindate.Value;
            DateTime checkOutDate = checkoutdate.Value;

            if (IsReservationOverlap(roomNumber, checkInDate, checkOutDate))
            {
                MessageBox.Show("Another reservation already exists for the selected room and overlapping dates. Please select different dates or a different room.");
                return;
            }

            string clientName = RetrieveClientName(clientId); 

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    decimal reservationPrice = CalculateReservationPrice(Convert.ToInt32(roomNumber), checkInDate, checkOutDate);

                    decimal clientBudget = RetrieveClientBudget(clientId);

                    if (clientBudget < reservationPrice)
                    {
                        MessageBox.Show("Unenough budget. Please choose a different room or adjust the reservation.");
                        return;
                    }

                    DeductReservationPriceFromBudget(clientId, reservationPrice);

                    string query = "INSERT INTO reservations (room_number, client_id, client_name, check_in_date, check_out_date, price) VALUES (@RoomNumber, @ClientId, @ClientName, @CheckInDate, @CheckOutDate, @Price)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@RoomNumber", roomNumber);
                        command.Parameters.AddWithValue("@ClientId", clientId);
                        command.Parameters.AddWithValue("@ClientName", clientName); 
                        command.Parameters.AddWithValue("@CheckInDate", checkInDate.ToString("yyyy-MM-dd"));
                        command.Parameters.AddWithValue("@CheckOutDate", checkOutDate.ToString("yyyy-MM-dd"));
                        command.Parameters.AddWithValue("@Price", reservationPrice);
                        command.ExecuteNonQuery();
                    }

                    MarkRoomAsBusy(connection, roomNumber);
                    MessageBox.Show("Reservation added successfully!");
                    getBudget();
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }


        private decimal RetrieveClientBudget(int clientId)
        {
            decimal budget = 0;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT budget FROM client WHERE client_id = @ClientId";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ClientId", clientId);
                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            budget = Convert.ToDecimal(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving client budget: " + ex.Message);
            }
            return budget;
        }

        private int GetLastReservationId()
        {
            
            int reservationId = 0;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT MAX(reservation_id) FROM reservations";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        object result = command.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            reservationId = Convert.ToInt32(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving last reservation ID: " + ex.Message);
            }
            return reservationId;
        }

        private string RetrieveClientName(int clientId)
        {
            string clientName = string.Empty;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT name FROM client WHERE client_id = @ClientId";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ClientId", clientId);
                        clientName = command.ExecuteScalar()?.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving client name: " + ex.Message);
            }
            return clientName;
        }


        private void ClearFields()
        {
            roomnumbercombobox.Text = "";
            checkindate.Value = DateTime.Now;
            checkoutdate.Value = DateTime.Now;
        }

        private bool IsReservationOverlap(string roomNumber, DateTime checkInDate, DateTime checkOutDate, int reservationId = -1)
        {
            try
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM reservations WHERE room_number = @RoomNumber AND reservation_id != @ReservationId AND (@CheckInDate < check_out_date AND @CheckOutDate > check_in_date)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RoomNumber", roomNumber);
                    command.Parameters.AddWithValue("@CheckInDate", checkInDate);
                    command.Parameters.AddWithValue("@CheckOutDate", checkOutDate);
                    command.Parameters.AddWithValue("@ReservationId", reservationId);
                    int overlapCount = (int)command.ExecuteScalar();
                    return overlapCount > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking reservation overlap: " + ex.Message);
                return true;
            }
            finally
            {
                connection.Close();
            }
        }

        private decimal CalculateReservationPrice(int roomNumber, DateTime checkInDate, DateTime checkOutDate)
        {
            decimal price = 0;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT ro.type AS 'Room Type', ro.[view] AS 'Room View' FROM room ro WHERE room_number = @RoomNumber";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@RoomNumber", roomNumber);
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            int roomTypeIndex = typecombobox.FindStringExact(reader["Room Type"].ToString());
                            int roomViewIndex = viewcombobox.FindStringExact(reader["Room View"].ToString());

                            decimal basePrice = roomPrices[roomTypeIndex, roomViewIndex];

                            int duration = (int)(checkOutDate - checkInDate).TotalDays;

                            price = basePrice * duration;
                        }
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error calculating reservation price: " + ex.Message);
            }

            return price;
        }


        private void DeductReservationPriceFromBudget(int clientId, decimal reservationPrice)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE client SET budget = budget - @ReservationPrice WHERE client_id = @ClientId";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@ReservationPrice", reservationPrice);
                        updateCommand.Parameters.AddWithValue("@ClientId", clientId);
                        updateCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deducting reservation price from client's budget: " + ex.Message);
            }
        }


        private void close_button_Click(object sender, EventArgs e)
        {

            login login = new login();
            login.Show();
            this.Hide();
        }

        private void getBudget()
        {

            string query = "SELECT budget AS TotalBudget " +
                "FROM client " + 
                "WHERE client_id = @clientId";


            using (SqlCommand command = new SqlCommand(query, connection))
            {
                try
                {
                    command.Parameters.AddWithValue("@clientId", clientId);

                    connection.Open();

                    object result = command.ExecuteScalar();

                    if (result != DBNull.Value)
                    {
                        budgettextbox.Text = "Your budget is: $ " + Convert.ToDouble(result).ToString(); 
                    }
                    else
                    {
                        budgettextbox.Text = "0";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clientmessage c = new clientmessage(clientId);
            c.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            viewreservation v = new viewreservation(clientId);
            v.Show();
            this.Hide();
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string fileName;
            string projectDirectory;
            string imagePath;
            if (e.RowIndex >= 0)
            {
                string roomType = dgv.Rows[e.RowIndex].Cells["Room Type"].Value.ToString();
                string roomView = dgv.Rows[e.RowIndex].Cells["Room View"].Value.ToString();

                if (roomType.ToString() == "Single" && roomView.ToString() == "Mountain")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Single" && roomView.ToString() == "Sea")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Single" && roomView.ToString() == "Pool")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Single" && roomView.ToString() == "Garden")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Double" && roomView.ToString() == "Garden")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Double" && roomView.ToString() == "Pool")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Double" && roomView.ToString() == "Sea")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }

                else if (roomType.ToString() == "Double" && roomView.ToString() == "Mountain")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Family" && roomView.ToString() == "Sea")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                }
            }

                else if (roomType.ToString() == "Family" && roomView.ToString() == "Mountain")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Family" && roomView.ToString() == "Garden")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Family" && roomView.ToString() == "Pool")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Suite" && roomView.ToString() == "Sea")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Suite" && roomView.ToString() == "Mountain")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();

                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Suite" && roomView.ToString() == "Pool")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                               
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
                else if (roomType.ToString() == "Suite" && roomView.ToString() == "Garden")
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT photo FROM room_image WHERE room_type = @RoomType AND room_view = @RoomView";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RoomType", roomType.ToString());
                            command.Parameters.AddWithValue("@RoomView", roomView.ToString());
                            byte[] imageData = (byte[])command.ExecuteScalar();
                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    pictureBox1.Image = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No image available for this room.");
                            }
                        }
                    }
                }
            }

            else
            {
                MessageBox.Show("Please select the room type and view to see the room picture");
            }
        }

      

    }
}
