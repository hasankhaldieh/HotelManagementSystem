﻿namespace HotelManagementSystem
{
    partial class client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.parrotClock1 = new ReaLTaiizor.Controls.ParrotClock();
            this.typecombobox = new System.Windows.Forms.ComboBox();
            this.viewcombobox = new System.Windows.Forms.ComboBox();
            this.roomnumbercombobox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.close_button = new System.Windows.Forms.Button();
            this.addbtn = new System.Windows.Forms.Button();
            this.checkindate = new System.Windows.Forms.DateTimePicker();
            this.checkoutdate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.budgettextbox = new System.Windows.Forms.TextBox();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // parrotClock1
            // 
            this.parrotClock1.CircleThickness = 6;
            this.parrotClock1.CompositingQualityType = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
            this.parrotClock1.DisplayFormat = ReaLTaiizor.Controls.ParrotClock.HourFormat.TwentyFourHour;
            this.parrotClock1.FilledHourColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(190)))), ((int)(((byte)(155)))));
            this.parrotClock1.FilledMinuteColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(70)))));
            this.parrotClock1.FilledSecondColor = System.Drawing.Color.DarkOrchid;
            this.parrotClock1.Font = new System.Drawing.Font("Impact", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.parrotClock1.HexagonColor = System.Drawing.SystemColors.Highlight;
            this.parrotClock1.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear;
            this.parrotClock1.Location = new System.Drawing.Point(186, 430);
            this.parrotClock1.Margin = new System.Windows.Forms.Padding(10);
            this.parrotClock1.Name = "parrotClock1";
            this.parrotClock1.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            this.parrotClock1.ShowAmPm = false;
            this.parrotClock1.ShowHexagon = false;
            this.parrotClock1.ShowMinutesCircle = true;
            this.parrotClock1.ShowSecondsCircle = true;
            this.parrotClock1.Size = new System.Drawing.Size(199, 179);
            this.parrotClock1.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            this.parrotClock1.TabIndex = 63;
            this.parrotClock1.Text = "parrotClock1";
            this.parrotClock1.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            this.parrotClock1.TimeAMFormat = "hh:mm";
            this.parrotClock1.TimeColor = System.Drawing.SystemColors.Highlight;
            this.parrotClock1.TimePMFormat = "HH:mm";
            this.parrotClock1.UnfilledHourColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(70)))), ((int)(((byte)(85)))));
            this.parrotClock1.UnfilledMinuteColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(70)))));
            this.parrotClock1.UnfilledSecondColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(70)))));
            // 
            // typecombobox
            // 
            this.typecombobox.FormattingEnabled = true;
            this.typecombobox.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Family",
            "Suite"});
            this.typecombobox.Location = new System.Drawing.Point(160, 238);
            this.typecombobox.Margin = new System.Windows.Forms.Padding(10);
            this.typecombobox.Name = "typecombobox";
            this.typecombobox.Size = new System.Drawing.Size(225, 21);
            this.typecombobox.TabIndex = 62;
            // 
            // viewcombobox
            // 
            this.viewcombobox.FormattingEnabled = true;
            this.viewcombobox.Items.AddRange(new object[] {
            "Sea",
            "Moutain",
            "Garden",
            "Pool"});
            this.viewcombobox.Location = new System.Drawing.Point(160, 278);
            this.viewcombobox.Margin = new System.Windows.Forms.Padding(10);
            this.viewcombobox.Name = "viewcombobox";
            this.viewcombobox.Size = new System.Drawing.Size(225, 21);
            this.viewcombobox.TabIndex = 61;
            // 
            // roomnumbercombobox
            // 
            this.roomnumbercombobox.FormattingEnabled = true;
            this.roomnumbercombobox.Location = new System.Drawing.Point(160, 319);
            this.roomnumbercombobox.Margin = new System.Windows.Forms.Padding(10);
            this.roomnumbercombobox.Name = "roomnumbercombobox";
            this.roomnumbercombobox.Size = new System.Drawing.Size(225, 21);
            this.roomnumbercombobox.TabIndex = 60;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label6.Location = new System.Drawing.Point(21, 278);
            this.label6.Margin = new System.Windows.Forms.Padding(10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 19);
            this.label6.TabIndex = 58;
            this.label6.Text = "Room View";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label5.Location = new System.Drawing.Point(21, 238);
            this.label5.Margin = new System.Windows.Forms.Padding(10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 19);
            this.label5.TabIndex = 57;
            this.label5.Text = "Room Type";
            // 
            // close_button
            // 
            this.close_button.BackColor = System.Drawing.SystemColors.Highlight;
            this.close_button.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_button.ForeColor = System.Drawing.SystemColors.Window;
            this.close_button.Location = new System.Drawing.Point(25, 599);
            this.close_button.Margin = new System.Windows.Forms.Padding(10);
            this.close_button.Name = "close_button";
            this.close_button.Size = new System.Drawing.Size(155, 45);
            this.close_button.TabIndex = 55;
            this.close_button.Text = "LOG OFF";
            this.close_button.UseVisualStyleBackColor = false;
            this.close_button.Click += new System.EventHandler(this.close_button_Click);
            // 
            // addbtn
            // 
            this.addbtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.addbtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addbtn.ForeColor = System.Drawing.SystemColors.Window;
            this.addbtn.Location = new System.Drawing.Point(25, 446);
            this.addbtn.Margin = new System.Windows.Forms.Padding(10);
            this.addbtn.Name = "addbtn";
            this.addbtn.Size = new System.Drawing.Size(155, 45);
            this.addbtn.TabIndex = 51;
            this.addbtn.Text = "Add";
            this.addbtn.UseVisualStyleBackColor = false;
            this.addbtn.Click += new System.EventHandler(this.addbtn_Click);
            // 
            // checkindate
            // 
            this.checkindate.Location = new System.Drawing.Point(160, 362);
            this.checkindate.Margin = new System.Windows.Forms.Padding(10);
            this.checkindate.Name = "checkindate";
            this.checkindate.Size = new System.Drawing.Size(225, 20);
            this.checkindate.TabIndex = 50;
            // 
            // checkoutdate
            // 
            this.checkoutdate.Location = new System.Drawing.Point(160, 405);
            this.checkoutdate.Margin = new System.Windows.Forms.Padding(10);
            this.checkoutdate.Name = "checkoutdate";
            this.checkoutdate.Size = new System.Drawing.Size(225, 20);
            this.checkoutdate.TabIndex = 49;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label4.Location = new System.Drawing.Point(21, 319);
            this.label4.Margin = new System.Windows.Forms.Padding(10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 19);
            this.label4.TabIndex = 48;
            this.label4.Text = "Room Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label3.Location = new System.Drawing.Point(21, 362);
            this.label3.Margin = new System.Windows.Forms.Padding(10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 19);
            this.label3.TabIndex = 47;
            this.label3.Text = "Check in date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label2.Location = new System.Drawing.Point(21, 405);
            this.label2.Margin = new System.Windows.Forms.Padding(10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 19);
            this.label2.TabIndex = 46;
            this.label2.Text = "Check out date";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Highlight;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(25, 548);
            this.button1.Margin = new System.Windows.Forms.Padding(10);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 45);
            this.button1.TabIndex = 64;
            this.button1.Text = "Message Staff";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // budgettextbox
            // 
            this.budgettextbox.BackColor = System.Drawing.SystemColors.Highlight;
            this.budgettextbox.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.budgettextbox.ForeColor = System.Drawing.SystemColors.Window;
            this.budgettextbox.Location = new System.Drawing.Point(186, 615);
            this.budgettextbox.Margin = new System.Windows.Forms.Padding(10);
            this.budgettextbox.Multiline = true;
            this.budgettextbox.Name = "budgettextbox";
            this.budgettextbox.ReadOnly = true;
            this.budgettextbox.Size = new System.Drawing.Size(199, 29);
            this.budgettextbox.TabIndex = 67;
            this.budgettextbox.Text = "Your budget is: ";
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.BackgroundColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgv.Location = new System.Drawing.Point(25, 22);
            this.dgv.Margin = new System.Windows.Forms.Padding(10);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(360, 196);
            this.dgv.TabIndex = 68;
            this.dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellClick);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Highlight;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.Window;
            this.button2.Location = new System.Drawing.Point(25, 497);
            this.button2.Margin = new System.Windows.Forms.Padding(10);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(155, 45);
            this.button2.TabIndex = 69;
            this.button2.Text = "View Reservations";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(415, 22);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(720, 622);
            this.pictureBox1.TabIndex = 70;
            this.pictureBox1.TabStop = false;
            // 
            // client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1163, 668);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.budgettextbox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.parrotClock1);
            this.Controls.Add(this.typecombobox);
            this.Controls.Add(this.viewcombobox);
            this.Controls.Add(this.roomnumbercombobox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.close_button);
            this.Controls.Add(this.addbtn);
            this.Controls.Add(this.checkindate);
            this.Controls.Add(this.checkoutdate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "client";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "client reservation";
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ReaLTaiizor.Controls.ParrotClock parrotClock1;
        private System.Windows.Forms.ComboBox typecombobox;
        private System.Windows.Forms.ComboBox viewcombobox;
        private System.Windows.Forms.ComboBox roomnumbercombobox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button close_button;
        private System.Windows.Forms.Button addbtn;
        private System.Windows.Forms.DateTimePicker checkindate;
        private System.Windows.Forms.DateTimePicker checkoutdate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox budgettextbox;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}