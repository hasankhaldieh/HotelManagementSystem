﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class clientmessage : Form
    {
        private int clientId;
      
        public clientmessage(int clientId)
        {
            InitializeComponent();
            this.clientId = clientId;
            LoadStaffResponse();
            msgtxtbx.Text = "Enter your message here";
            msgtxtbx.Tag = "Enter your message here";
            msgtxtbx.ForeColor = SystemColors.GrayText;
            msgtxtbx.GotFocus += TextBox_GotFocus;
            msgtxtbx.LostFocus += TextBox_LostFocus;
            

        }

        private void LoadStaffResponse()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;"))
                {
                    connection.Open();
                    string query = "SELECT message FROM message WHERE client_id = @ClientId AND staff_id IS NOT NULL";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ClientId", clientId);
                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            responsetxtbx.ForeColor = SystemColors.WindowText;
                            responsetxtbx.Text = result.ToString();
                        }
                        else
                        {
                            responsetxtbx.Text = "Staff response goes here";
                            responsetxtbx.Tag = "Staff response goes here";
                            responsetxtbx.ForeColor = SystemColors.GrayText;
                            responsetxtbx.GotFocus += TextBox_GotFocus;
                            responsetxtbx.LostFocus += TextBox_LostFocus;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading response: " + ex.Message);
            }
        }

        private void sendbtn_Click(object sender, EventArgs e)
        {
            string message = msgtxtbx.Text.Trim();

            if (message=="Enter your message here")
            {
                MessageBox.Show("Please enter a message to send.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;"))
                {
                    connection.Open();
                    string query = "IF EXISTS (SELECT 1 FROM message WHERE client_id = @ClientId AND staff_id IS NOT NULL) " +
                                   "UPDATE message SET message = @Message, staff_id = NULL  WHERE client_id = @ClientId " +
                                   "ELSE " +
                                   "INSERT INTO message (client_id, staff_id, message) VALUES (@ClientId, NULL, @Message)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ClientId", clientId);
                        command.Parameters.AddWithValue("@Message", message);
                        command.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("message sent");
                msgtxtbx.Clear();
                responsetxtbx.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error sending message: " + ex.Message);
            }
        }

        private void close_button_Click(object sender, EventArgs e)
        {
            login login = new login();
            login.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            client c = new client(clientId);
            c.Show();
            this.Hide();
        }
      

       
       

        private void TextBox_GotFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (textBox.Text == textBox.Tag.ToString())
            {
                textBox.Text = "";
                textBox.ForeColor = SystemColors.WindowText;
            }
           
        }

        private void TextBox_LostFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = textBox.Tag.ToString();
                textBox.ForeColor = SystemColors.GrayText;
                
            }
        }
      
    }
}