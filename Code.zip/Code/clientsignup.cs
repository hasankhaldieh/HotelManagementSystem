﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace HotelManagementSystem
{
    public partial class clientsignup : Form
    {
        public clientsignup()
        {
            InitializeComponent();

        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;");
        SqlCommand cmd = new SqlCommand();



        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            login login = new login();
            login.Show();
            this.Hide();
        }

        private void create_button_Click(object sender, EventArgs e)
        {
            if (IsInvalidTextBox(nametextbox, "Enter your name") ||
                IsInvalidTextBox(usernametextbox, "Enter your username") ||
                IsInvalidTextBox(passwordtextbox, "Enter your password") ||
                IsInvalidTextBox(emailtextbox, "Enter your email") ||
                IsInvalidTextBox(phonenumbertextbox, "Enter your phone number"))
            {
                return;
            }

            string name = nametextbox.Text.Trim();
            string username = usernametextbox.Text.Trim();
            string password = passwordtextbox.Text.Trim();
            string email = emailtextbox.Text.Trim();
            string phoneNumber = phonenumbertextbox.Text.Trim();

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Enter a valid email address");
                return;
            }

            if (!IsValidLebanonPhoneNumber(phoneNumber))
            {
                MessageBox.Show("Phone number must be a valid Lebanese phone number.");
                return;
            }

            if (!IsValidPassword(password))
            {
                MessageBox.Show("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-A4NJ3PI;Initial Catalog=hotel;Integrated Security=True;"))
                {
                    connection.Open();

                    string checkUsernameQuery = "SELECT COUNT(*) FROM client WHERE username = @username";
                    using (SqlCommand checkUsernameCmd = new SqlCommand(checkUsernameQuery, connection))
                    {
                        checkUsernameCmd.Parameters.AddWithValue("@username", username);
                        int existingUserCount = (int)checkUsernameCmd.ExecuteScalar();
                        if (existingUserCount > 0)
                        {
                            MessageBox.Show("Username already exists. Please choose a different username.");
                            return;
                        }
                    }

                    string insertClientQuery = "INSERT INTO [client] (name, username, password, email, phonenumber) VALUES (@name, @username, @password, @email, @phonenumber)";
                    using (SqlCommand cmd = new SqlCommand(insertClientQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.Parameters.AddWithValue("@email", email);
                        cmd.Parameters.AddWithValue("@phonenumber", phoneNumber);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Signed up successfully");
                        ClearTextBoxes();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private bool IsValidEmail(string email)
        {
            if (email.Count(c => c == '@') != 1)
            {
                return false;
            }

            string[] parts = email.Split('@');
            string localPart = parts[0];
            string domainPart = parts[1];

            if (string.IsNullOrWhiteSpace(localPart) || string.IsNullOrWhiteSpace(domainPart))
            {
                return false;
            }

            int dotIndex = domainPart.IndexOf('.');
            if (dotIndex == -1 || dotIndex == 0 || dotIndex == domainPart.Length - 1)
            {
                return false;
            }

            if (localPart[0] == '@' || localPart[localPart.Length - 1] == '@' ||
                domainPart[0] == '.' || domainPart[domainPart.Length - 1] == '.')
            {
                return false;
            }

            if (localPart.Contains(".") && localPart.IndexOf(".") == localPart.IndexOf("@") + 1)
            {
                return false;
            }

            string localPartPattern = @"^[^@]*[a-zA-Z][^@]*$";
            if (!Regex.IsMatch(localPart, localPartPattern))
            {
                return false;
            }

            int atIndex = email.IndexOf('@');
            int comIndex = email.LastIndexOf("com");

            if (comIndex == -1 || atIndex == -1 || email[atIndex + 1] == '.' || email.Substring(atIndex + 1, comIndex - atIndex - 1).Count(c => c == '.') != 1 || email.IndexOf('.', atIndex) != comIndex - 1)
            {
                return false;
            }
            return true;
        }




        private bool IsValidLebanonPhoneNumber(string phoneNumber)
        {
            string lebanonPattern = @"^(\+?961|0)?(3|70|71|76|78|81)\d{6}$";

            return Regex.IsMatch(phoneNumber, lebanonPattern);
        }


        private bool IsValidPassword(string password)
        {
            return password.Length >= 8 && password.Any(char.IsUpper) && password.Any(char.IsLower) && password.Any(char.IsDigit) && password.Any(c => !char.IsLetterOrDigit(c));
        }

        private bool IsInvalidTextBox(TextBox textbox, string placeholder)
        {
            if (string.IsNullOrWhiteSpace(textbox.Text) || textbox.Text == placeholder)
            {
                MessageBox.Show($"Enter your {textbox.Tag.ToString().ToLower()}");
                return true;
            }
            return false;
        }

        private void ClearTextBoxes()
        {
            nametextbox.Clear();
            usernametextbox.Clear();
            passwordtextbox.Clear();
            emailtextbox.Clear();
            phonenumbertextbox.Clear();
        }


        private void TextBox_GotFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (textBox.Text == textBox.Tag.ToString())
            {
                textBox.Text = "";
                textBox.ForeColor = SystemColors.WindowText;
            }
        }

        private void TextBox_LostFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = textBox.Tag.ToString();
                textBox.ForeColor = SystemColors.GrayText;
            }
        }
        private void signup_Load(object sender, EventArgs e)
        {
            nametextbox.Text = "Enter your name";
            nametextbox.Tag = "Enter your name";
            nametextbox.ForeColor = SystemColors.GrayText;
            nametextbox.GotFocus += TextBox_GotFocus;
            nametextbox.LostFocus += TextBox_LostFocus;
            usernametextbox.Text = "Enter your username";
            usernametextbox.Tag = "Enter your username";
            usernametextbox.ForeColor = SystemColors.GrayText;
            usernametextbox.GotFocus += TextBox_GotFocus;
            usernametextbox.LostFocus += TextBox_LostFocus;
            passwordtextbox.Text = "Enter your password";
            passwordtextbox.Tag = "Enter your password";
            passwordtextbox.ForeColor = SystemColors.GrayText;
            passwordtextbox.GotFocus += TextBoxGotFocus;
            passwordtextbox.LostFocus += TextBoxLostFocus;
            emailtextbox.Text = "Enter your email";
            emailtextbox.Tag = "Enter your email";
            emailtextbox.ForeColor = SystemColors.GrayText;
            emailtextbox.GotFocus += TextBox_GotFocus;
            emailtextbox.LostFocus += TextBox_LostFocus;
            phonenumbertextbox.Text = "Enter your phone number";
            phonenumbertextbox.Tag = "Enter your phone number";
            phonenumbertextbox.ForeColor = SystemColors.GrayText;
            phonenumbertextbox.GotFocus += TextBox_GotFocus;
            phonenumbertextbox.LostFocus += TextBox_LostFocus;


        }

        private void phonenumbertextbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void passwordtextbox_TextChanged(object sender, EventArgs e)
        {
            passwordtextbox.PasswordChar.ToString();
        }

        private void TextBoxGotFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (textBox.Text == textBox.Tag.ToString())
            {
                textBox.Text = "";
                textBox.ForeColor = SystemColors.WindowText;
            }
            if (textBox.Name == "passwordtextbox")
            {
                textBox.PasswordChar = '*';
            }
        }

        private void TextBoxLostFocus(object sender, EventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = textBox.Tag.ToString();
                textBox.ForeColor = SystemColors.GrayText;
                if (textBox.Name == "passwordtextbox")
                {
                    textBox.PasswordChar = '\0';
                }
            }
        }
    }
}
